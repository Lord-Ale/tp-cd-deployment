export declare class Task {
    id: number;
    title: string;
    content: string | null;
    done: boolean;
    createdAt: Date;
}
