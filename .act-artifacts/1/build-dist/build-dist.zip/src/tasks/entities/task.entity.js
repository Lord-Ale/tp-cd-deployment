"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Task = void 0;
class Task {
    id;
    title;
    content;
    done;
    createdAt;
}
exports.Task = Task;
//# sourceMappingURL=task.entity.js.map