export declare class CreateTaskDto {
    title: string;
    content?: string;
    done?: boolean;
}
